The fonts available on my site
Kat's Fun Fonts
www.katsfunfonts.com
are freeware font files!
:)

This means:

This font was created by me, Kat Rakos.

You may use it for personal use only.  You know as well as I do what 'personal use only' so please don't play games with me and try to get around it.  If you honestly do NOT understand how the font world works, shoot me a note (katsfunfonts@hotmail or kat@katsfunfonts.com) and I'll explain it all to you :)

Legal mumbo jumbo: 

MY FILES MAY NOT BE USED FOR COMMERCIAL PURPOSES OR SOLD IN ANY WAY
without prior communication, WRITTEN authorization from me.  Copyright permissions are available for sale.

My fonts MAY be placed on any website available for download, providing proper CREDIT is given, a link back
to me and this README.txt file is left in tact and attached to all of MY files you offer for download.
YOU MAY NOT directly link to my site or use my images or use my bandwith to offer the files.
You do need to contact me first though for permission.  Shoot me a note and I'll get you one right back
and you can put the zips right up :)

I am not and can not be held resposible for any damages incurred to any computer after installing and/or using this font.

All fonts have been made my me or with freeware/royalty free images.  If you made any of the images or know who did, write me and I'll remove it from my site immediately upon confirmation.  No need to get all IPPITY :)  I don't want people taking my work.  I surely wouldn't want to be known for taking someone elses!

If you use this font for a project you're proud of, let me see it !  I'd like to see what you did with it!

You can see all of my fonts at www.katsfunfonts.com

If you like this font or have an idea for a font, let me know!  Send your mail to katsfunfonts@hotmail.com
or kat@katsfunfonts.com


Hugs

Kat